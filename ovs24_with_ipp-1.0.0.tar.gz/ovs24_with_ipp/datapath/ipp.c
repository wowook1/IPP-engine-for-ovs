#include "flow.h"
#include "datapath.h"

#include <linux/uaccess.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/if_ether.h>
#include <linux/if_vlan.h>
#include <net/llc_pdu.h>
#include <linux/kernel.h>
#include <linux/llc.h>
#include <linux/module.h>
#include <linux/in.h>
#include <linux/if_arp.h>
#include <linux/ip.h>
#include <linux/ipv6.h>
#include <linux/sctp.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/icmp.h>
#include <linux/icmpv6.h>
#include <linux/rculist.h>
#include <net/ip.h>
#include <net/ipv6.h>
#include <net/ndisc.h>

#include "ipp.h"

#define IPP_DEBUG

#ifdef IPP_MODE_SINGLE
	struct ipp_engine *ipp_single; 	// in single mode, there's a global ipp engine used by all datapaths
#endif // IPP_MODE_SINGLE 


//read a line from ipp code. returns one of ipp code line classifiers.
int ipp_readline (char **p_remain_str, char *line_str, int *line_len)
{
	int ret;
	bool readline;
	int line_size;
	bool end;
	char *remain_str;

	*line_len = 0;
	remain_str = *p_remain_str;
	//1. trim ahead of the line (EOF, space, tab, LF)
	readline = false;

	while (readline == false)
	{
		switch (*remain_str)
		{
			case '\0':
				return IPP_LINE_EOF;
				break;
			case '\n':
			case '\r':
				remain_str++;
				*p_remain_str = remain_str;
				return IPP_LINE_TRIMED;
				break;
			case ' ':
			case '\t':
				remain_str++;
				break;
			default:
				readline = true;
				break;
						
		}
	}

	//2. classify DIRECTIVE/INSTRUCTION/COMMENT
	if (*remain_str == ';')	//comment
	{
		while (*remain_str != '\n') 
		{
			if (*remain_str == '\0') {
				*p_remain_str = remain_str;
				return IPP_LINE_EOF;
			}
			remain_str++;
		}
		remain_str++;
		*p_remain_str = remain_str;
		return IPP_LINE_TRIMED;
	} else if (*remain_str == '%') ret = IPP_LINE_DIRECTIVE; //preprocessor directive
	else ret = IPP_LINE_INSTRUCTION; //instruction


	//3. readline until meets LF, EOF, comment
	line_size = 0;
	end = false;
	
	while (end == false)
	{
		switch (*remain_str)
		{
			case '\0':
				end = true;
				break;
			case '\n':
				remain_str++;
				end = true;
				break;
			case ';':
				while (*remain_str != '\n') 
				{
					if (*remain_str == '\0') break;
					remain_str++;
				}
				break;
			default:
				*(line_str + line_size) = *remain_str;
				line_size++;
				remain_str++;
				break;
		}
	}

	//close line_str and return
	*(line_str + line_size) = '\0';
	*line_len = line_size +1;
	
	*p_remain_str = remain_str;
	return ret;
}

//read a token from the line. returns one of ipp code token classifiers.
int ipp_readtoken (char **p_line_str, char *token_str, int *token_len, int *token_val)
{
	int token_size;
	bool readtoken;
	bool is_int;
	bool end;
	char *line_str;
	
	line_str = *p_line_str;
	*token_len = 0;
	*token_val = 0;
	
	token_size = 0;

	//1. trim ahead of the token (EOF, space, tab, LF, comma)
	readtoken = false;
	
	while (readtoken == false)
	{
		switch (*line_str)
		{
			case '\0':
				*p_line_str = line_str;
				return IPP_TOKEN_EOF;
				break;
			case '\n':
			case ';':
				printk(KERN_ERR "[IPP] ipp_readtoken error (LF/comment in token)\n");
				*p_line_str = line_str;
				return IPP_TOKEN_EOF;
				break;
			case ' ':
			case '\t':
			case ',':
				line_str++;
				break;
			default:
				readtoken = true;
				break;
		}
	}

	//2. process string token
	if (*line_str == '\"')	// string
	{
		line_str++;
		while (*line_str != '\"') 
		{
			if (*line_str == '\0') {
				*p_line_str = line_str;
				return IPP_TOKEN_EOF;
			}
			*(token_str + token_size) = *line_str;
			token_size++;
			line_str++;
		}
		line_str++;
		
		*(token_str + token_size) = '\0';
		*token_len = token_size +1;
		
		*p_line_str = line_str;
		return IPP_TOKEN_STRING;
	}

	//3. process square bracket token
	if (*line_str == '[')	// string
	{
		line_str++;
		while (*line_str != ']') 
		{
			if (*line_str == '\0') {
				*p_line_str = line_str;
				return IPP_TOKEN_EOF;
			}
			*(token_str + token_size) = *line_str;
			token_size++;
			line_str++;
		}
		line_str++;
		
		*(token_str + token_size) = '\0';
		*token_len = token_size +1;
		
		*p_line_str = line_str;
		return IPP_TOKEN_BRACKET;
	}


	//4. process arithmetic operator token
	if ((*line_str == '+') || (*line_str == '-') || (*line_str == '*') || (*line_str == '/'))	// string
	{
		*token_str = *line_str;
		token_size++;

		line_str++;
		
		*(token_str + token_size) = '\0';
		*token_len = token_size +1;
		
		*p_line_str = line_str;
		return IPP_TOKEN_OPERATOR;
	}

	//5. process other tokens until meets LF, EOF, space, tab, comma
	is_int = true;
	end = false;
	
	while (end == false)
	{
		switch (*line_str)
		{
			case '\0':
				end = true;
				break;
			case '\n':
			case ' ':
			case '\t':
			case ',':
				line_str++;
				end = true;
				break;
			default:
				*(token_str + token_size) = *line_str;
				if ((*line_str < '0') || ('9' < *line_str)) is_int = false;
				
				token_size++;
				line_str++;
				break;
		}
	}
	*(token_str + token_size) = '\0';	//close token_str
	*token_len = token_size +1;
	
	//6. classify label token
	if (*(token_str + token_size -1) == ':')	// abc:
	{
		if (token_size <= 1) 
		{
			printk(KERN_ERR "[IPP] ipp_readtoken error (label has no identifier)\n");
			*p_line_str = line_str;
			return IPP_TOKEN_EOF;
		}

		// cut ':' and return
		*(token_str + token_size -1) = '\0';
		*token_len = token_size;
		*p_line_str = line_str;
		return IPP_TOKEN_LABEL;
	}

	//7. classify integer value token
	if (((*token_str == '0') && (*(token_str + 1) == 'x'))	// 0x1234
		|| (is_int == true))								// 01234 or 1234
	{
		long token_val_temp;
		if (kstrtol(token_str, 0, &token_val_temp) == 0) 
		{
			*token_val = (int)token_val_temp;
			*p_line_str = line_str;
			return IPP_TOKEN_INTEGER;
		}
	}
	
	*p_line_str = line_str;
	return IPP_TOKEN_ELSE;
}

int ipp_readoperand (struct ipp_instance *proc, struct ipp_instruction *inst, char *operand_str, int len, int addr_mode)
{
	char *remain_str;
	char *token_str;
	int token_len;
	int token_val;

	char *temp_str;
	int temp_len;
	int temp_val;
	int temp_type;

	char *vector1;
	char *vector2;
	vector1 = kmalloc(IPP_MAX_TOKENLEN, GFP_KERNEL);
	vector2 = kmalloc(IPP_MAX_TOKENLEN, GFP_KERNEL);
		
	// if addr_mode is NULL, try all modes to find suitable addr_mode for the operand
	if (addr_mode == 0)
		addr_mode = IPP_ADDR_MODE_0 | IPP_ADDR_MODE_1 | IPP_ADDR_MODE_2 | IPP_ADDR_MODE_3
			 | IPP_ADDR_MODE_4 | IPP_ADDR_MODE_5 | IPP_ADDR_MODE_6 | IPP_ADDR_MODE_7
			 | IPP_ADDR_MODE_8 | IPP_ADDR_MODE_9 | IPP_ADDR_MODE_10;	// consider null operand later...

	//mode 0.	// x/%x           // Register X
	if (addr_mode & IPP_ADDR_MODE_0)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		if (token_len == 1) {
			if (token_str[0] != 'x') break;
		} else if (token_len == 2) {
			if((token_str[0] != '%') || (token_str[1] != 'x')) break;
		} else break;

		//set operands
		inst->operand[0] = 0;
		inst->operand_type[0] = IPP_OPERAND_REG_X; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_0;
					
		return IPP_ADDR_MODE_0;
	} while (0);
	
	//mode 1. 	// [k]            // BHW at byte offset k in the packet (k=integer or variable)
	if (addr_mode & IPP_ADDR_MODE_1)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_BRACKET) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		temp_type = ipp_readtoken (&token_str, temp_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, temp_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		if (ipp_readtoken (&token_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		
		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_1;
		
		return IPP_ADDR_MODE_1;
	} while (0);

	//mode 2. 	// [x + k]        // BHW at the offset X + k in the packet
	if (addr_mode & IPP_ADDR_MODE_2)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_BRACKET) break;
		if (ipp_readtoken (&remain_str, temp_str, &token_len, &token_val) != IPP_TOKEN_EOF) break;
		if (ipp_readtoken (&token_str, temp_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if ((temp_str[0] != 'x') || (token_len != 2)) break;
		if (ipp_readtoken (&token_str, temp_str, &token_len, &token_val) != IPP_TOKEN_OPERATOR) break;
		if ((temp_str[0] != '+') || (token_len != 2)) break;

		temp_type = ipp_readtoken (&token_str, temp_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, temp_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		if (ipp_readtoken (&token_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		//set operands
		inst->operand[0] = 0;
		inst->operand_type[0] = IPP_OPERAND_REG_X; 
		inst->operand[1] = token_val;
		inst->operand_type[1] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE;  
		inst->num_operand = 2;
		inst->addr_mode = IPP_ADDR_MODE_2;
		
		return IPP_ADDR_MODE_2;
	} while (0);
	
	//mode 3. 	// M[k]           // Word at offset k in M[]
	if (addr_mode & IPP_ADDR_MODE_3)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		if (token_str[0] != 'M') break;
		
		// (delete 'M' and check again)
		remain_str = operand_str + 1;
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_BRACKET) break;
		
		temp_type = ipp_readtoken (&token_str, temp_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, temp_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		if (ipp_readtoken (&token_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_3;
		
		return IPP_ADDR_MODE_3;
	} while (0);

	//mode 4. 	// #k             // Literal value stored in k
	if (addr_mode & IPP_ADDR_MODE_4)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		if (token_str[0] != '#') break;

		// (delete '#' and check again)
		remain_str = operand_str + 1;
		temp_type = ipp_readtoken (&remain_str, token_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, token_str, token_len);
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] read_operand mode4: find_var result:%d \n", token_val);
#endif //IPP_DEBUG
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		
		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_4;
					
		return IPP_ADDR_MODE_4;
	} while (0);

	//mode 5. 	// 4*([k]&0xf)    // Lower nibble * 4 at byte offset k in the packet
	if (addr_mode & IPP_ADDR_MODE_5)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		if (token_str[0] != '4') break;
		if (token_str[1] != '*') break;
		if (token_str[2] != '(') break;
		
		// (delete "4*(" and check again)
		remain_str = operand_str + 3;
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_BRACKET) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_ELSE) break;
		if (temp_str[0] != '&') break;
		if (temp_str[1] != '0') break;
		if (temp_str[2] != 'x') break;
		if (temp_str[3] != 'f') break;
		if (temp_str[4] != ')') break;
		if (temp_len != 6) break;
		
		temp_type = ipp_readtoken (&token_str, temp_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, temp_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		if (ipp_readtoken (&token_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_5;
		
		return IPP_ADDR_MODE_5;
	} while (0);

	//mode 6.	// L              // Jump label L
	if (addr_mode & IPP_ADDR_MODE_6)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		token_val = ipp_find_label_by_name(proc, token_str, token_len);
		if (token_val == -1) break;
		
		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = IPP_OPERAND_OFFSET; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_6;
		
		return IPP_ADDR_MODE_6;
	} while (0);

	
	//mode 7. 	// #k,Lt,Lf       // Jump to Lt if true, otherwise jump to Lf
	if (addr_mode & IPP_ADDR_MODE_7)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		// first operand 
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (token_str[0] != '#') break;

		// (delete '#' and check again)
		remain_str = operand_str + 1;
		temp_type = ipp_readtoken (&remain_str, token_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, token_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 

		// second operand 
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;

		token_val = ipp_find_label_by_name(proc, token_str, token_len);
		if (token_val == -1) break;

		inst->operand[1] = token_val;
		inst->operand_type[1] = IPP_OPERAND_OFFSET; 

		// third operand
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		token_val = ipp_find_label_by_name(proc, token_str, token_len);
		if (token_val == -1) break;

		inst->operand[2] = token_val;
		inst->operand_type[2] = IPP_OPERAND_OFFSET; 
		
		// finish
		inst->num_operand = 3;
		inst->addr_mode = IPP_ADDR_MODE_7;
					
		return IPP_ADDR_MODE_7;
	} while (0);

	//mode 8. 	// #k,Lt          // Jump to Lt if predicate is true
	if (addr_mode & IPP_ADDR_MODE_8)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		// first operand 
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (token_str[0] != '#') break;

		// (delete '#' and check again)
		remain_str = operand_str + 1;
		temp_type = ipp_readtoken (&remain_str, token_str, &token_len, &token_val);
		if (temp_type == IPP_TOKEN_ELSE)
		{	
			token_val = ipp_find_var_by_name(proc, token_str, token_len);
			if (token_val == -1) break;
		}
		else if (temp_type != IPP_TOKEN_INTEGER) break;
		
		inst->operand[0] = token_val;
		inst->operand_type[0] = (temp_type == IPP_TOKEN_INTEGER)? IPP_OPERAND_VALUE : IPP_OPERAND_VARIABLE; 

		// second operand 
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		token_val = ipp_find_label_by_name(proc, token_str, token_len);
		if (token_val == -1) break;

		inst->operand[1] = token_val;
		inst->operand_type[1] = IPP_OPERAND_OFFSET; 
		
		// finish
		inst->num_operand = 2;
		inst->addr_mode = IPP_ADDR_MODE_8;
					
		return IPP_ADDR_MODE_8;
	} while (0);

	//mode 9. 	// a/%a           // Accumulator A
	if (addr_mode & IPP_ADDR_MODE_9)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
		if (token_len == 1) {
			if (token_str[0] != 'a') break;
		} else if (token_len == 2) {
			if((token_str[0] != '%') || (token_str[1] != 'a')) break;
		} else break;

		//set operands
		inst->operand[0] = 0;
		inst->operand_type[0] = IPP_OPERAND_REG_A; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_9;
		
		return IPP_ADDR_MODE_9;
	} while (0);

	//mode 10 	// extension      // BPF extension
	if (addr_mode & IPP_ADDR_MODE_10)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE) break;
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;
	
		token_val = ipp_find_ext_by_name(token_str, token_len);
		if (token_val == -1) break;
		
		//set operands
		inst->operand[0] = token_val;
		inst->operand_type[0] = IPP_OPERAND_EXT; 
		inst->num_operand = 1;
		inst->addr_mode = IPP_ADDR_MODE_10;
		
		return IPP_ADDR_MODE_10;
	} while (0);

	//mode NULL 	// (null)		// No operand
	if (addr_mode & IPP_ADDR_MODE_NULL)
	do { 
		remain_str = operand_str;
		memset(vector1, 0, IPP_MAX_TOKENLEN);
		memset(vector2, 0, IPP_MAX_TOKENLEN);
		token_str = vector1;
		temp_str = vector2;

		//check validity
		if (ipp_readtoken (&remain_str, temp_str, &temp_len, &temp_val) != IPP_TOKEN_EOF) break;

		//set operands
		inst->num_operand = 0;
		inst->addr_mode = IPP_ADDR_MODE_NULL;
		
		return IPP_ADDR_MODE_NULL;
	} while (0);

	//return result_addr;
	return -1;
}

// ipp code parsing and install (makes new instance of the processor)
int ipp_install_processor (struct ipp_engine *ipp, char *prog, int prog_size, const struct vport *vport)
{
	struct ipp_instance *new_ipp;
	struct ipp_active_list *new_active; 

	char *remain_str;
	char *line_str;
	int line_len;

	char *token_str;
	int token_len;
	int token_val;
	int token_type;
	bool valid_code;
	int addr_mode;
	bool code_end;
	int i;
	
	char *vector1;
	char *vector2;

	//to add a new instruction
	int cur_line;	//# of instruction line (directives are not counted)
	struct ipp_instruction *new_inst;
	char *new_code_line;
	char *new_label;

	vector1 = kmalloc(IPP_MAX_LINELEN, GFP_KERNEL);
	vector2 = kmalloc(IPP_MAX_LINELEN, GFP_KERNEL);

	new_ipp = ipp_instance_init();
	line_len = 0;
	token_len = 0;
	token_val = 0;
	token_type = 0;
	valid_code = true;
	cur_line = 0;

	// START_PRE_PROCESSING
	remain_str = prog;
	code_end = false;

#ifdef IPP_DEBUG
	printk(KERN_ERR "----------------------------------------------\n");
	printk(KERN_ERR "[IPP] installing new prog:\n%s", prog);
#endif //IPP_DEBUG

	// spinlock ipp engine data structure
	spin_lock(&ipp->engine_lock);

#ifdef IPP_DEBUG
	printk(KERN_ERR "----------------------------------------------\n");
	printk(KERN_ERR "[IPP]              << start pre-processing >> \n");
#endif //IPP_DEBUG
	while (code_end == false)
	{
		new_inst = NULL;
		new_code_line = NULL;
		new_label = NULL;

		memset(vector1, 0, IPP_MAX_LINELEN);
		memset(vector2, 0, IPP_MAX_LINELEN);
		line_str = vector1;
		token_str = vector2;
	
		// 1. read a trimmed line from ipp code
		switch (ipp_readline(&remain_str, line_str, &line_len))
		{
			case IPP_LINE_EOF:
				code_end = true;
				break;
			case IPP_LINE_TRIMED:
				break;
			// 2. parse preprocessor directives code
			case IPP_LINE_DIRECTIVE:
				// 2-1. get directive token
				if (ipp_readtoken(&line_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE)
				{
					printk(KERN_ERR "[IPP] ipp_install_processor error (directive token error)\n");
						
					valid_code = false;
					code_end = true;
					break;
				}

				// 2-2. process %setid
				if (strncmp(token_str, "%setid", 6) == 0) { 	
					if (ipp_readtoken(&line_str, token_str, &token_len, &token_val) != IPP_TOKEN_INTEGER)
					{
						printk(KERN_ERR "[IPP] ipp_install_processor error (%%setid: token error)\n");
							
						valid_code = false;
						code_end = true;
						break;
					}
					// check if the id is valid
					if (token_val < 0)
					{
						printk(KERN_ERR "[IPP] ipp_install_processor error (%%setid: id must be a positive integer)\n");
							
						valid_code = false;
						code_end = true;
						break;
					}
					// check if the id already installed
					if (ipp_find_processor_by_id(ipp, token_val) != NULL)
					{
						printk(KERN_ERR "[IPP] ipp_install_processor error (%%setid: id already installed)\n");
							
						valid_code = false;
						code_end = true;
						break;
					}
					// check if the id violates reserved area
					if (token_val <= IPP_ID_RESERVED) 
						printk(KERN_ERR "[IPP] ipp_install_processor warn (%%setid: attempt to use reserved id %d. reserved id range: 0~%d))\n", ipp->next_temp_id, IPP_ID_RESERVED);
			
					new_ipp->id = token_val;
#ifdef IPP_DEBUG
	printk(KERN_ERR "[IPP] (%%setid): %d\n", new_ipp->id);
#endif //IPP_DEBUG
				} 

				// 2-3. process %addvar
				else if (strncmp(token_str, "%addvar", 7) == 0) {
					//read var_name
					if (ipp_readtoken(&line_str, token_str, &token_len, &token_val) != IPP_TOKEN_ELSE)
					{
						printk(KERN_ERR "[IPP] ipp_install_processor error (%%addvar: token error)\n");
							
						valid_code = false;
						code_end = true;
						break;
					}
					//check var_name validity
					if (ipp_find_operator_by_name(token_str, token_len, &addr_mode) || (ipp_find_var_by_name(new_ipp, token_str, token_len) != -1) 
						|| (ipp_find_str_by_name(new_ipp, token_str, token_len) != -1) || (ipp_find_label_by_name(new_ipp, token_str, token_len) != -1))
					{
						printk(KERN_ERR "[IPP] ipp_install_processor error (%%addvar: cannot use this var_name)\n");
													
						valid_code = false;
						code_end = true;
						break;
					}
					//copy var_name
					new_ipp->var[new_ipp->var_num].var_name = kmalloc(token_len, GFP_KERNEL);
					strncpy(new_ipp->var[new_ipp->var_num].var_name, token_str, token_len);

					//set var initial value (if exist)
					if (ipp_readtoken(&line_str, token_str, &token_len, &token_val) == IPP_TOKEN_INTEGER)
						new_ipp->var[new_ipp->var_num].var = token_val;
					else
						new_ipp->var[new_ipp->var_num].var = 0;
#ifdef IPP_DEBUG
	printk(KERN_ERR "[IPP] (%%addvar): %s, %d (var_num = %d)\n", new_ipp->var[new_ipp->var_num].var_name, new_ipp->var[new_ipp->var_num].var, new_ipp->var_num);
#endif //IPP_DEBUG
					new_ipp->var_num++;
				} 

				// 2-4. process %addstr
				else if (strncmp(token_str, "%addstr", 7) == 0) {
					//fill later


				}

				// 2-5. process %setpriority
				else if (strncmp(token_str, "%setpriority", 12) == 0) {
					//fill later
				
				
				}

				break;
				
			// 3. put each instruction code lines to instruction list (not compiling)
			case IPP_LINE_INSTRUCTION:

				// 3-1. copy code_line 
				new_code_line = kmalloc(line_len, GFP_KERNEL);
				strncpy(new_code_line, line_str, line_len);
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] (instruction) %s \n", new_code_line);				
#endif //IPP_DEBUG
				
				// 3-2. get instruction token
				token_type = ipp_readtoken(&line_str, token_str, &token_len, &token_val);
				
				// (optional) if label exists, copy label and readtoken again.
				if (token_type == IPP_TOKEN_LABEL) 
				{
					new_label = kmalloc(token_len, GFP_KERNEL);	
					strncpy(new_label, token_str, token_len);
					token_type = ipp_readtoken(&line_str, token_str, &token_len, &token_val);
				}

				if ((token_type != IPP_TOKEN_EOF) && (token_type != IPP_TOKEN_ELSE))
				{
					printk(KERN_ERR "[IPP] ipp_install_processor error (instruction token error: %d)\n", token_type);
						
					valid_code = false;
					code_end = true;

					kfree(new_code_line);
					kfree(new_label);
					break;
				}

				// 3-3. save code_line and label
				new_inst = kmalloc(sizeof(struct ipp_instruction), GFP_KERNEL); 
				new_inst->code_line = new_code_line;
				new_inst->line_len = line_len;
				new_inst->label = new_label;
				
				// 3-4. add new_inst to instruction list
				new_ipp->inst[new_ipp->inst_num] = new_inst;
				new_ipp->inst_num++;

				break;
		}
	}

	// START_COMPILE
#ifdef IPP_DEBUG
	printk(KERN_ERR "----------------------------------------------\n");
#endif //IPP_DEBUG
	code_end = false;

	addr_mode = 0;
	for(i = 0; i < new_ipp->inst_num; i++)
	{
		memset(vector1, 0, IPP_MAX_LINELEN);
		memset(vector2, 0, IPP_MAX_LINELEN);
		line_str = vector1;
		token_str = vector2;

		if ((valid_code == false) || (code_end == true)) break;
		new_code_line = new_ipp->inst[i]->code_line;
		line_len = new_ipp->inst[i]->line_len;


#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] -------------Compile instruction #%d --------------- \n", i);				
#endif //IPP_DEBUG
		// 1. get instruction token
		token_type = ipp_readtoken(&new_code_line, token_str, &token_len, &token_val); 
		line_len -= token_len; 
		if (token_type == IPP_TOKEN_LABEL)
		{ 
			token_type = ipp_readtoken(&new_code_line, token_str, &token_len, &token_val);
			line_len -= token_len;

			// if the line has label only (has no instruction)
			if (token_type == IPP_TOKEN_EOF) {
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] (this instruction has label only) \n");
#endif //IPP_DEBUG
				new_ipp->inst[i]->opcode = NULL;
				continue;
			}
		}

		// 2. set opcode
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] (set operator) %s (len %d, end with %d) \n", token_str, token_len, token_str[token_len-1]);				
#endif //IPP_DEBUG
		new_ipp->inst[i]->opcode = ipp_find_operator_by_name(token_str, token_len, &addr_mode);
		if (new_ipp->inst[i]->opcode == NULL)
		{
			printk(KERN_ERR "[IPP] ipp_install_processor error (set opcode error on \"%s\")\n", new_ipp->inst[i]->code_line);

			valid_code = false;
			code_end = true;
			break;
		}

		// 3. set operands
		if ((addr_mode = ipp_readoperand(new_ipp, new_ipp->inst[i], new_code_line, line_len, addr_mode)) == -1)
		{
			printk(KERN_ERR "[IPP] ipp_install_processor error (set operand error on \"%s\")\n", new_ipp->inst[i]->code_line);

			valid_code = false;
			code_end = true;
			break;
		}
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] (set operands) %s (addr_mode = %d) \n", new_ipp->inst[i]->code_line, addr_mode);				
#endif //IPP_DEBUG	
	}

	// ATTACH_INSTANCE_LIST_ENTRY

	if (valid_code == true) 
	{
		// add new instance to instance list
		ipp_find_last_processor(ipp)->next = new_ipp;
		ipp->num_instance++;

		// if id == -1, assign a temp id and show the id to user (and set allow_call = false)
		if (new_ipp->id == -1)
		{
			while (ipp_find_processor_by_id(ipp, ipp->next_temp_id) != NULL) ipp->next_temp_id++;
			
			if (ipp->next_temp_id >= IPP_ID_RESERVED) 
				printk(KERN_ERR "[IPP] ipp_install_processor warn (reserved id full: temp id %d)\n", ipp->next_temp_id);
			
			new_ipp->id = ipp->next_temp_id;
		}
	
		// if active == true, add this instance to active list (and set allow_call = false)
		if (new_ipp->active == true)
		{
			new_active = ipp_active_init();
			new_active->instance = new_ipp;
			new_active->id = new_ipp->id;
			
			ipp_find_last_active(ipp)->next = new_active;
			ipp->num_active++;
		}

#ifdef IPP_DEBUG
	printk(KERN_ERR "[IPP] ipp_install_processor success (id: %d)\n", ipp_find_last_processor(ipp)->id);
	printk(KERN_ERR "----------------------------------------------\n");
#endif //IPP_DEBUG

		// unlock
		spin_unlock(&ipp->engine_lock);
		return 0;
	}
	else
	{
		ipp_instance_free(new_ipp);
		spin_unlock(&ipp->engine_lock);
		return -1;
	}
}


int ipp_uninstall_processor (struct ipp_engine *ipp, int id)
{
	struct ipp_instance *ipp_inst;
	
	//search tatget ipp by its id
	ipp_inst = ipp_find_processor_by_id (ipp, id);

	//remove the processor from instance lists 
	// fill later:


	//free
	if (ipp_inst == NULL) return -1;
	else kfree(ipp_inst); return 0;
}

// IPP engine called by each arriving packet
// return 0 for packet processing finished
// return others for vender-dependent processing needed (1: "norm" action, -1: error occured)
#ifdef __IPP_FOR_OVS
int ipp_engine_run (struct datapath *dp, struct ipp_engine *ipp, struct sk_buff *skb, struct sw_flow_key *key)
#else //__IPP_FOR_OVS
int ipp_engine_run (struct ipp_engine *ipp, struct sk_buff *skb)
#endif //__IPP_FOR_OVS
{
	int result;
	struct ipp_active_list *cur_active;
	struct ipp_instance *cur_proc;
	int i;
	int last_pc;

	// initialize packet metadata
	struct ipp_packet_metadata pkt;
	memset(&pkt, 0, sizeof(struct ipp_packet_metadata));
	pkt.skb = skb;
#ifdef __IPP_FOR_OVS
	pkt.key = key;
#endif //__IPP_FOR_OVS

	// run each processor
	cur_active = ipp->active_list; //first entry is a list header (null ipp_active_list)
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] ipp_engine_run (num_active: %d)---------\n", ipp->num_active);				
#endif //IPP_DEBUG

	for(i=0; i<ipp->num_active; i++)
	{
		cur_active = cur_active->next;
		cur_proc = cur_active->instance;
		
		// spinlock instance
		spin_lock(&cur_proc->instance_lock);
		// initialize volatile variables
		cur_proc->PC = 0;
		cur_proc->A = 0;
		cur_proc->X = 0;
		cur_proc->nskb = NULL;
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] ---------ipp_engine_run for active list #%d (processor id: %d)---------\n", i, cur_proc->id);				
#endif //IPP_DEBUG
		// run instructions	
		while((0 <= cur_proc->PC) && (cur_proc->PC < cur_proc->inst_num))
		{
			last_pc = cur_proc->PC;
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] run instruction %d/%d (%s)\n", cur_proc->PC, cur_proc->inst_num-1, cur_proc->inst[cur_proc->PC]->code_line);				
#endif //IPP_DEBUG
			if (cur_proc->inst[cur_proc->PC]->opcode == NULL)
			{
				cur_proc->PC++;
				continue;
			}
			else
			{
				result = (cur_proc->inst[cur_proc->PC]->opcode)(cur_proc, &pkt, cur_proc->inst[cur_proc->PC]);
				if (result != 0) {
					printk(KERN_DEBUG "[IPP] instruction fail, result: %d (0 is okay) \n", result);				
					break;	// if instruction fail, exit instruction loop of this processor 
				}
			}

			//each instruction must changes PC (++, jmp, end)
			if (last_pc == cur_proc->PC) {
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP]  instruction must changes PC! (%s) \n", cur_proc->inst[cur_proc->PC]->code_line);				
#endif //IPP_DEBUG				
				cur_proc->PC++;
			}
		}

		// unlock instance
		spin_unlock(&cur_proc->instance_lock);
	}

	//apply actions
	#ifdef IPP_MODE_SINGLE
	return ipp_run_action(dp, ipp, &pkt);
	#else
	return ipp_run_action(ipp, &pkt);
	#endif
}

#ifdef IPP_MODE_SINGLE
//in single mode, a global ipp engine is used by multiple datapaths
int ipp_run_action(struct datapath *dp, struct ipp_engine *ipp, struct ipp_packet_metadata *pkt)
#else
int ipp_run_action(struct ipp_engine *ipp, struct ipp_packet_metadata *pkt)
#endif
{
	bool ignore;
	bool normal;
	bool used;

	int i;
	int j;

	ignore = false;	//when ign is set, lower priority actions are blocked
	normal = false;	//when norm is set, vender dependent packet processing is called for this pkt (after IPP processing finished)
	used = false; //when the original skb is not used to send, it must be consumed

	// run action list for each priority
	for(i=0; i<=IPP_MAX_PRIORITY; i++)
	{
		//ignore check
		if (ignore == true) break;

		//get action status for the priority
		if (pkt->action_list[i].ignore == true) 
			ignore = true;

		if (pkt->action_list[i].normal == true) {
			normal = true;
			used = true;	//packet would be used for vender dependent processing
		}

		//run packet_out
		for(j=0; j<pkt->action_list[i].out_num; j++)
		{
			struct sk_buff *out_skb;

			if (pkt->action_list[i].out_skb[j] == NULL)	
				out_skb = skb_clone(pkt->skb, GFP_ATOMIC);	//original skb used
			else
				out_skb = skb_clone(pkt->action_list[i].out_skb[j], GFP_ATOMIC);

			if (out_skb) {
				#ifdef IPP_MODE_SINGLE
				ipp_pkt_output(dp, out_skb, pkt->action_list[i].out_port[j]);
				#else //IPP_MODE_SINGLE
				ipp_pkt_output(ipp->dp, out_skb, pkt->action_list[i].out_port[j]);
				#endif //IPP_MODE_SINGLE
				used = true;	//packet would be used for output
			}
		}	
	}

	//if this packet would not be used, free skb
	if (!used) consume_skb(pkt->skb);

	if (normal)  
		return 1;
	else
		return 0;
}

void ipp_pkt_output(struct datapath *dp, struct sk_buff *skb, int out_port)
{
	struct vport *vport = ovs_vport_rcu(dp, out_port);

	if (likely(vport)) {
#ifdef IPP_DEBUG
		printk(KERN_DEBUG "[IPP] ipp_pkt_output (vport.port_no = %d) \n", vport->port_no);				
#endif //IPP_DEBUG
		ovs_vport_send(vport, skb);
	}
	else {
		printk(KERN_DEBUG "[IPP] ipp_pkt_output: fail \n");
		kfree_skb(skb);
	}
}

/* ipp utils */
#ifdef IPP_MODE_SINGLE
struct ipp_engine *ipp_engine_init (void)
#else //IPP_MODE_SINGLE
struct ipp_engine *ipp_engine_init (struct datapath *dp)
#endif //IPP_MODE_SINGLE
{
	struct ipp_engine *ipp;
	ipp = kmalloc(sizeof(struct ipp_engine), GFP_KERNEL);
	
	spin_lock_init(&ipp->engine_lock);
#ifndef IPP_MODE_SINGLE
	ipp->dp = dp;
#endif
	ipp->num_instance = 0;
	ipp->instance_list = ipp_instance_init();	//instance list header (null ipp_instance)
	ipp->num_active = 0;
	ipp->active_list = ipp_active_init();	//active list header (null ipp_active_list)
	
	ipp->status = IPP_STATUS_WAITING;
	//fill later: initializing code
	ipp->next_temp_id = 1;

	return ipp;
}


int ipp_engine_free (struct ipp_engine *ipp)
{
	//fill later: free each memory in engine


	kfree(ipp);
	
	return 0;
}

struct ipp_instance *ipp_instance_init (void)
{
	struct ipp_instance *new_ipp;
	new_ipp	= kmalloc(sizeof(struct ipp_instance), GFP_KERNEL);

	spin_lock_init(&new_ipp->instance_lock);
	new_ipp->next = NULL;
	new_ipp->id = -1;
	new_ipp->action_priority = IPP_DEF_PRIORITY;
	new_ipp->active = true;
	new_ipp->allow_call = true;
	new_ipp->prog_size = 0;
	new_ipp->inst_num = 0;
	new_ipp->str_num = 0;
	new_ipp->var_num = 0;

	//initialize non-volatile memory
	memset(new_ipp->M, 0, sizeof(new_ipp->M));
	
#ifdef __IPP_FOR_OVS
	new_ipp->key_extract = true;
#endif //__IPP_FOR_OVS
	
	return new_ipp;
}

int ipp_instance_free (struct ipp_instance *instance)
{
	//fill later: free each memory in instance


	kfree(instance);
	return 0;
}

struct ipp_active_list *ipp_active_init (void)
{
	struct ipp_active_list *new_active;
	new_active = kmalloc(sizeof(struct ipp_active_list), GFP_KERNEL);

	new_active->next = NULL;
	new_active->instance = NULL;
	new_active->id = -1;

	return new_active;
}

int ipp_active_free(struct ipp_active_list *active)
{
	kfree(active);
	return 0;
}


/* string matching functions (return NULL if no matched name found) */


//int ipp_find_operator_by_name (char * token,int len, char *addr_mode)
int (*ipp_find_operator_by_name(char *token, int len, int *addr_mode))(struct ipp_instance *, struct ipp_packet_metadata *, struct ipp_instruction *)
{
	// LD
	if (strncmp(token, "ld", 3) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_1 | IPP_ADDR_MODE_2 | IPP_ADDR_MODE_3 | IPP_ADDR_MODE_4 | IPP_ADDR_MODE_10;
		return ipp_operator_ld;
	}
	else if (strncmp(token, "ldi", 4) == 0)
	{
		*addr_mode = IPP_ADDR_MODE_4;
		//return ipp_operator_ldi;
	}
	else if (strncmp(token, "ldh", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_1 | IPP_ADDR_MODE_2;
		return ipp_operator_ldh;
	} 
	else if (strncmp(token, "ldb", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_1 | IPP_ADDR_MODE_2;
		return ipp_operator_ldb;
	}
	else if (strncmp(token, "st", 3) == 0)
	{
		*addr_mode = IPP_ADDR_MODE_3 | IPP_ADDR_MODE_4;
		return ipp_operator_st;
	}

	// JMP
	else if (strncmp(token, "jmp", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_6;
		return ipp_operator_jmp;
	}
	else if (strncmp(token, "jeq", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_7 | IPP_ADDR_MODE_8;
		return ipp_operator_jeq;
	}
	else if (strncmp(token, "jne", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_8;
		return ipp_operator_jne;
	}
	else if (strncmp(token, "ret", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_4 | IPP_ADDR_MODE_9;
		return ipp_operator_ret;
	}

	// ALU
	else if (strncmp(token, "add", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_0 | IPP_ADDR_MODE_4;
		return ipp_operator_add;
	}
	else if (strncmp(token, "mod", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_0 | IPP_ADDR_MODE_4;
		return ipp_operator_mod;
	}

	// ipp-extended operator
	else if (strncmp(token, "out", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_4;
		return ipp_operator_out;
	}
	else if (strncmp(token, "ign", 4) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_NULL;
		return ipp_operator_ign;
	}
	else if (strncmp(token, "norm", 5) == 0) 
	{
		*addr_mode = IPP_ADDR_MODE_NULL;
		return ipp_operator_norm;
	}

	//fill later

	return NULL;
}


/* ipp data structure functions */
int ipp_find_ext_by_name(char *token, int len)
{
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] find_ext_by_name: %s (len %d, end with %d) \n", token, len, token[len-1]);
#endif //IPP_DEBUG
	if (strncmp(token, "len", 4) == 0) 
	{
		return IPP_EXT_LEN;
	}
	else if (strncmp(token, "proto", 6) == 0)
	{
		return IPP_EXT_PROTO;
	}
	
	//fill later

	return -1;
}

int ipp_find_var_by_name(struct ipp_instance *proc, char *token, int len)
{
	int i;
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] find_var_by_name: %s (len %d, end with %d) \n", token, len, token[len-1]);
#endif //IPP_DEBUG
	for (i=0; i < proc->var_num; i++)
	{
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] find_var_by_name: var[%d/%d] is %s \n", i, proc->var_num, proc->var[i].var_name);
#endif //IPP_DEBUG
		if (strncmp(proc->var[i].var_name, token, len) == 0) 
			return i;
	}
	
	return -1;
}

int ipp_find_str_by_name(struct ipp_instance *proc, char *token, int len)
{
	int i;
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] find_str_by_name: %s (len %d, end with %d) \n", token, len, token[len-1]);
#endif //IPP_DEBUG
	for (i=0; i < proc->str_num; i++)
	{
		if (strncmp(proc->str[i].str_name, token, len) == 0) 
			return i;
	}
	
	return -1;
}

int ipp_find_label_by_name(struct ipp_instance *proc, char *token, int len)
{
	int i;
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] find_label_by_name: %s (len %d, end with %d) \n", token, len, token[len-1]);
#endif //IPP_DEBUG
	for (i=0; i < proc->inst_num; i++)
	{	
		if (proc->inst[i]->label != NULL)
		if (strncmp(proc->inst[i]->label, token, len) == 0) 
			return i;
	}

	return -1;
}


// find a processor by its id
struct ipp_instance* ipp_find_processor_by_id (struct ipp_engine *ipp, int id)
{
	struct ipp_instance *temp;
	int i;
	
	temp = ipp->instance_list;
	
	//caution: first entry of instance list is list header (null instance) 
	
	for (i=0; i<ipp->num_instance; i++)
	{
		temp = temp->next;
		if (temp == NULL) return NULL;
		else if (temp->id == id) return temp;
	}
	return NULL;	
}


// find a processor by its id, and return its prev
struct ipp_instance* ipp_find_prev_processor_by_id (struct ipp_engine *ipp, int id)
{
	struct ipp_instance *temp;
	int i;

	temp = ipp->instance_list;

	//caution: first entry of instance list is list header (null instance) 
		
	
	for (i=0; i<ipp->num_instance; i++)
	{
		if (temp->next == NULL) return NULL;
		else if (temp->next->id == id) return temp;
		else temp = temp->next;
	}
	return NULL;
}


// find last entry in processor list
struct ipp_instance* ipp_find_last_processor (struct ipp_engine *ipp)
{
	struct ipp_instance *temp;
	int i;

	temp = ipp->instance_list;

	//caution: first entry of instance list is list header (null instance) 
		
	for (i=0; i<ipp->num_instance+1; i++)
	{
		if (temp->next == NULL) return temp;
		else temp = temp->next;
	}
	return NULL;
}


// find a processor in active list by its id
struct ipp_active_list* ipp_find_active_by_id (struct ipp_engine *ipp, int id)
{
	struct ipp_active_list *temp;
	int i;

	temp = ipp->active_list;
	
	//caution: first entry of instance list is list header (null instance) 

	for (i=0; i<ipp->num_active; i++)
	{
		temp = temp->next;
		if (temp == NULL) return NULL;
		else if (temp->id == id) return temp;
	}
	return NULL;	
}

// find a processor in active list by its id, and return its prev
struct ipp_active_list* ipp_find_prev_active_by_id (struct ipp_engine *ipp, int id)
{
	struct ipp_active_list *temp;
	int i;

	temp = ipp->active_list;
	
	//caution: first entry of instance list is list header (null instance) 
		
	for (i=0; i<ipp->num_active; i++)
	{
		if (temp->next == NULL) return NULL;
		else if (temp->next->id == id) return temp;
		else temp = temp->next;
	}
	return NULL;	
}

// find last entry in active list
struct ipp_active_list* ipp_find_last_active (struct ipp_engine *ipp)
{
	struct ipp_active_list *temp;
	int i;

	temp = ipp->active_list;
	
	//caution: first entry of instance list is list header (null instance) 
		
	for (i=0; i<ipp->num_active+1; i++)
	{
		if (temp->next == NULL) return temp;
		else temp = temp->next;
	}
	return NULL;	
}

/**** http://vger.kernel.org/~davem/skb_data.html ****/
/**** datapath/ovs_packet_cmd_execute() ****/
/* ipp operator functions */

// 1, 2, 3, 4, 10		// Load word into A
int ipp_operator_ld(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;

	char *src;
	uint32_t dst;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_1:	// [k]		// BHW at byte offset k in the packet
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			src = pkt->skb->head + k+2;
			memcpy (&dst, src, sizeof(uint32_t));
			processor->A = ntohl(dst);
			break;
		case IPP_ADDR_MODE_2:	// [x + k]	// BHW at the offset X + k in the packet
			k= (inst->operand_type[1] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[1]].var : inst->operand[1];
			src = pkt->skb->head + processor->X + k+2;
			memcpy (&dst, src, sizeof(uint32_t));
			processor->A = ntohl(dst);
			break;
		case IPP_ADDR_MODE_3:	// M[k]		// Word at offset k in M[]
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			processor->A = processor->M[k];
			break;
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			processor->A = (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			break;
		case IPP_ADDR_MODE_10:	// extension	// BPF extension
			// fill later:
			processor->A = 0;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_ld error\n");
			return -1;
			break;
	}

	processor->PC++;
	
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_ld: load 0x%X on A \n", processor->A);
#endif //IPP_DEBUG

	return 0;
}

// 1, 2			// Load half-word into A
int ipp_operator_ldh(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;

	char *src;
	uint16_t dst;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_1:	// [k]		// BHW at byte offset k in the packet
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			src = pkt->skb->head + k+2;
			memcpy (&dst, src, sizeof(uint16_t));
			processor->A = ntohs(dst);
			break;
		case IPP_ADDR_MODE_2:	// [x + k]		// BHW at the offset X + k in the packet
			k= (inst->operand_type[1] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[1]].var : inst->operand[1];
			src = pkt->skb->head + processor->X + k+2;
			memcpy (&dst, src, sizeof(uint16_t));
			processor->A = ntohs(dst);
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_ldh error\n");
			return -1;
			break;
	}

	processor->PC++;

#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_ldh: load 0x%X on A \n", processor->A);
#endif //IPP_DEBUG

	return 0;
}

// 1, 2 		// Load byte into A
int ipp_operator_ldb(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;

	char *src;
	uint8_t dst;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_1:	// [k]		// BHW at byte offset k in the packet
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			src = pkt->skb->head + k+2;
			memcpy (&dst, src, sizeof(uint8_t));
			processor->A = dst;
			break;
		case IPP_ADDR_MODE_2:	// [x + k]	// BHW at the offset X + k in the packet
			k= (inst->operand_type[1] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[1]].var : inst->operand[1];
			src = pkt->skb->head + processor->X + k+2;
			memcpy (&dst, src, sizeof(uint8_t));
			processor->A = dst;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_ldb error\n");
			return -1;
			break;
	}

	processor->PC++;

#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_ldb: load 0x%X on A \n", processor->A);
#endif //IPP_DEBUG

	return 0;
}

// 3, 4		// Store A into M[] or variable k (if k is not a variable, returns error)
int ipp_operator_st(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_3:	// M[k]		// Word at offset k in M[]
			processor->M[inst->operand[0]] = processor->A;
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_st: store A(%d) to M[%ld] \n", processor->A, (unsigned long int)inst->operand[0]);
#endif //IPP_DEBUG
			break;
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			if (inst->operand_type[0] != IPP_OPERAND_VARIABLE) {
				printk(KERN_ERR "[IPP] ipp_operator_st error: operand is not a variable\n");
				return -1;
				break;
			}
			
			processor->var[inst->operand[0]].var = processor->A;
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_st: store A(%d) to variable %ld(%s) \n", processor->A, (unsigned long int)inst->operand[0], processor->var[inst->operand[0]].var_name);
#endif //IPP_DEBUG			
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_st error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}

// 6			// Jump to label
int ipp_operator_jmp(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_6:	// L              // Jump label L
			// operand is an instruction offset (IPP_OPERAND_OFFSET)
			processor->PC = inst->operand[0]; 
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_jmp error\n");
			return -1;
			break;
	}
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_jmp: jump to %d \n", processor->PC);
#endif //IPP_DEBUG

	return 0;
}

// 7, 8			// Jump on k == A
int ipp_operator_jeq(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
#ifdef IPP_DEBUG
	int temp;
	temp = processor->PC;
#endif //IPP_DEBUG
	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_7:	// #k,Lt,Lf	// Jump to Lt if true, otherwise jump to Lf
			// 1st operand is a value or a variable
			// 2nd operand is an instruction offset (IPP_OPERAND_OFFSET)
			if (inst->operand_type[0] == IPP_OPERAND_VALUE)
			{
				if (processor->A == inst->operand[0])
					processor->PC = inst->operand[1]; 
				else processor->PC = inst->operand[2];
			}
			else if (inst->operand_type[0] == IPP_OPERAND_VARIABLE)
			{
				if (processor->A == processor->var[inst->operand[0]].var)
					processor->PC = inst->operand[1]; 
				else processor->PC = inst->operand[2];
			}
			break;
		case IPP_ADDR_MODE_8:	// #k,Lt	// Jump to Lt if predicate is true
			// 1st operand is a value or a variable
			// 2nd operand is an instruction offset (IPP_OPERAND_OFFSET)
			if (inst->operand_type[0] == IPP_OPERAND_VALUE)
			{
				if (processor->A == inst->operand[0])
					processor->PC = inst->operand[1]; 
				else processor->PC++;
			}
			else if (inst->operand_type[0] == IPP_OPERAND_VARIABLE)
			{
				if (processor->A == processor->var[inst->operand[0]].var)
					processor->PC = inst->operand[1]; 
				else processor->PC++;
			}
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_jeq error\n");
			return -1;
			break;
	}
#ifdef IPP_DEBUG
	if (temp+1 != processor->PC)
		printk(KERN_DEBUG "[IPP] ipp_operator_jeq: jump to %d \n", processor->PC);
	else 	printk(KERN_DEBUG "[IPP] ipp_operator_jeq: not jump \n");
#endif //IPP_DEBUG
	return 0;
}

// 8			// Jump on k != A
int ipp_operator_jne(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
#ifdef IPP_DEBUG
	int temp;
	temp = processor->PC;
#endif //IPP_DEBUG
	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_8:	// #k,Lt	// Jump to Lt if predicate is true
			// 1st operand is a value or a variable
			// 2nd operand is an instruction offset (IPP_OPERAND_OFFSET)
			if (inst->operand_type[0] == IPP_OPERAND_VALUE)
			{
				if (processor->A != inst->operand[0])
					processor->PC = inst->operand[1]; 
				else processor->PC++;
			}
			else if (inst->operand_type[0] == IPP_OPERAND_VARIABLE)
			{
				if (processor->A != processor->var[inst->operand[0]].var)
					processor->PC = inst->operand[1]; 
				else processor->PC++;
			}
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_jne error\n");
			return -1;
			break;
	}
#ifdef IPP_DEBUG
	if (temp+1 != processor->PC)
		printk(KERN_DEBUG "[IPP] ipp_operator_jne: jump to %d \n", processor->PC);
	else 	printk(KERN_DEBUG "[IPP] ipp_operator_jne: not jump \n");
#endif //IPP_DEBUG

	return 0;
}

// 0, 4			// A + <x>
int ipp_operator_add(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_0:	// x/%x		// Register X
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_add (A = %d + %d)\n", processor->A, processor->X);
#endif //IPP_DEBUG
			processor->A = processor->A + processor->X;
			break;
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_add (A = %d + %ld)\n", processor->A, (unsigned long int)k);
#endif //IPP_DEBUG
			processor->A = processor->A + k;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_add error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}

// 0, 4			// A % <x>
int ipp_operator_mod(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_0:	// x/%x		// Register X
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_mod (A = %d %% %d)\n", processor->A, processor->X);
#endif //IPP_DEBUG
			processor->A = processor->A % processor->X;
			break;
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_mod (A = %d %% %ld)\n", processor->A, (unsigned long int)k);
#endif //IPP_DEBUG
			processor->A = processor->A % k;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_mod error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}

// 4, 9			// Return
int ipp_operator_ret(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			// 1st operand is a value or a variable
			// 2nd operand is an instruction offset (IPP_OPERAND_OFFSET)
			if (inst->operand_type[0] == IPP_OPERAND_VALUE)
			{
#ifdef IPP_DEBUG
				printk(KERN_ERR "[IPP] ipp_operator_ret (val: %ld) \n", (unsigned long int)(inst->operand[0]));
#endif //IPP_DEBUG
			}
			else if (inst->operand_type[0] == IPP_OPERAND_VARIABLE)
			{
#ifdef IPP_DEBUG
				printk(KERN_ERR "[IPP] ipp_operator_ret (val: %d) \n", processor->var[inst->operand[0]].var);
#endif //IPP_DEBUG
			}
			processor->PC = processor->inst_num;	// set PC to instruction end 
			break;
		case IPP_ADDR_MODE_9:	// a/%a		// Accumulator A
#ifdef IPP_DEBUG
			printk(KERN_ERR "[IPP] ipp_operator_ret (val: %d) \n", processor->A);
#endif //IPP_DEBUG
			processor->PC = processor->inst_num;	// set PC to instruction end 
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_ret error\n");
			return -1;
			break;
	}

	return 0;
}

// 4	// packet out to port k
int ipp_operator_out(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
	uint64_t k;
	uint8_t priority;
	uint8_t out_num;

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_4:	// #k		// Literal value stored in k
			k= (inst->operand_type[0] == IPP_OPERAND_VARIABLE) ? processor->var[inst->operand[0]].var : inst->operand[0];
			priority = processor->action_priority;
			out_num = pkt->action_list[priority].out_num;

			if (processor->nskb == NULL) //packet is not modified in this processor
				pkt->action_list[priority].out_skb[out_num] = skb_clone(pkt->skb, GFP_ATOMIC);
			else			//packet is modified to nskb
				pkt->action_list[priority].out_skb[out_num] = skb_clone(processor->nskb, GFP_ATOMIC);

			pkt->action_list[priority].out_port[out_num] = k;

			pkt->action_list[priority].out_num++;

#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_out: port %ld, priority %d, out_num %d \n", (unsigned long int)k, priority, out_num);
#endif //IPP_DEBUG
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_out error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}

// 11		// lower priority actions are blocked
int ipp_operator_ign(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_ign \n");
#endif //IPP_DEBUG

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_NULL:	// (null)	// No operand
			pkt->action_list[processor->action_priority].ignore = true;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_ign error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}

// 11		// vender dependent packet processing called (after IPP processing finished)
int ipp_operator_norm(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst)
{
#ifdef IPP_DEBUG
	printk(KERN_DEBUG "[IPP] ipp_operator_norm \n");
#endif //IPP_DEBUG

	switch (inst->addr_mode)
	{
		case IPP_ADDR_MODE_NULL:	// (null)	// No operand
			pkt->action_list[processor->action_priority].normal = true;
			break;
		default:
			printk(KERN_ERR "[IPP] ipp_operator_norm error\n");
			return -1;
			break;
	}

	processor->PC++;
	
	return 0;
}
