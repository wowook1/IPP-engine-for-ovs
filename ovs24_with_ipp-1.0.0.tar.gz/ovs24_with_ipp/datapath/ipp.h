#ifndef IPP_H
#define IPP_H 1

/* IPP v0.1 by Kiwook Kim.
 * IPP is a Instruction-based Packet Processing architecture,  
 * and inherits most of BPF instruction architecture.
 
 * About BPF, see this document for more information:
 * https://www.kernel.org/doc/Documentation/networking/filter.txt
 * 
 * at 09-27-2015
 */

/* (09-27-2015) write ipp code draft
 * (12-01-2015) finish attaching ipp engine to ovs (v0.1)
 * (11-02-2016) add char device for loader input, and modify overall codes as "single mode" for easy execution
 */


#define __IPP_FOR_OVS		// enables codes which have dependency on ovs 


#ifdef __IPP_FOR_OVS
#ifndef DATAPATH_H
#include "datapath.h"
//struct datapath *new_dp;	// a global variable for new datapath (by ovs_dp_cmd_new)
#endif //DATAPATH_H
#endif //__IPP_FOR_OVS


#include <linux/spinlock.h>




// data structures
struct ipp_instruction;
struct ipp_action_list;
struct ipp_user_var;
struct ipp_user_str;
struct ipp_engine;
struct ipp_active_list;
struct ipp_instance;
struct ipp_packet_metadata;

//set ipp mode single
#ifdef IPP_MODE_SINGLE
	extern struct ipp_engine *ipp_single; 	// in single mode, there's a global ipp engine used by all datapaths
#endif // IPP_MODE_SINGLE 


// ipp global setting
#define IPP_MAX_CODESIZE 	1024	//max code size of a filter 
#define IPP_MAX_LINELEN 	128	//max length of a instruction line 
#define IPP_MAX_LINENUM 	128	//max code lines (= # of instructions) of a filter
#define IPP_MAX_TOKENLEN	16	//max length of a token
#define IPP_MAX_STRING  	10	//max # of defined string in a filter
#define IPP_MAX_VARIABLE  	10	//max # of defined variable in a filter
#define IPP_MAX_ARG  		3	//max # of operand in a instruction
#define IPP_ID_RESERVED  	10000	//reserved id range (0~IPP_ID_RESERVED). user ipp id must be bigger than this value
#define IPP_MAX_PRIORITY  	7	//max level of priority. 0 is top priority level
#define IPP_DEF_PRIORITY  	5	//default priority for ipp action
#define IPP_MAX_PKTOUT	  	8	//max # of packet output for each priority level





//ext: ldc wtc out wrt wrth
//ext2: goto ign ?(access header)

// original operator id (see https://www.kernel.org/doc/Documentation/networking/filter.txt)
enum {
	// Instruction		// Addressing Mode	// Description
	IPP_OPERATOR_LD = 1,	// 1, 2, 3, 4, 10	// Load word into A
	IPP_OPERATOR_LDI,	// 4			// Load word into A
	IPP_OPERATOR_LDH,	// 1, 2			// Load half-word into A
	IPP_OPERATOR_LDB,	// 1, 2 		// Load byte into A
	IPP_OPERATOR_LDX,	// 3, 4, 5, 10		// Load word into X
	IPP_OPERATOR_LDXI,	// 4			// Load word into X
	IPP_OPERATOR_LDXB,	// 5			// Load byte into X
	
	IPP_OPERATOR_ST,	// 3, 4			// Store A into M[]	//revised at IPP
	IPP_OPERATOR_STX,	// 3			// Store X into M[]
	
	IPP_OPERATOR_JMP,	// 6			// Jump to label
	IPP_OPERATOR_JA,	// 6			// Jump to label
	IPP_OPERATOR_JEQ,	// 7, 8			// Jump on k == A
	IPP_OPERATOR_JNEQ,	// 8			// Jump on k != A
	IPP_OPERATOR_JNE,	// 8			// Jump on k != A
	IPP_OPERATOR_JLT,	// 8			// Jump on k < A
	IPP_OPERATOR_JLE,	// 8			// Jump on k <= A
	IPP_OPERATOR_JGT,	// 7, 8			// Jump on k > A
	IPP_OPERATOR_JGE,	// 7, 8			// Jump on k >= A
	IPP_OPERATOR_JSET,	// 7, 8			// Jump on k & A
	
	IPP_OPERATOR_ADD,	// 0, 4			// A + <x>
	IPP_OPERATOR_SUB,	// 0, 4			// A - <x>
	IPP_OPERATOR_MUL,	// 0, 4			// A * <x>
	IPP_OPERATOR_DIV,	// 0, 4			// A / <x>
	IPP_OPERATOR_MOD,	// 0, 4			// A % <x>
	IPP_OPERATOR_NEG,	// 0, 4			// !A
	IPP_OPERATOR_AND,	// 0, 4			// A & <x>
	IPP_OPERATOR_OR,	// 0, 4			// A | <x>
	IPP_OPERATOR_XOR,	// 0, 4			// A ^ <x>
	IPP_OPERATOR_LSH,	// 0, 4			// A << <x>
	IPP_OPERATOR_RSH,	// 0, 4			// A >> <x>

	IPP_OPERATOR_TAX,	// (null)		// Copy A into X
	IPP_OPERATOR_TXA,	// (null)		// Copy X into A

	IPP_OPERATOR_RET,	// 4, 9			// Return
	
	__IPP_OPERATOR_MAX
};

// ipp-extended operator id	(check later)
enum {
	IPP_OPERATOR_LDC = __IPP_OPERATOR_MAX,	//	//
	IPP_OPERATOR_WTC,	//	//
	
	IPP_OPERATOR_OUT,	// 4	// packet out to port k
	IPP_OPERATOR_WR,	//	// write to payload
	IPP_OPERATOR_HWR,	//	// write to header
	
	IPP_OPERATOR_CALL,	//	//
	IPP_OPERATOR_IGN,	// 11	// lower priority actions are blocked
	IPP_OPERATOR_NORM,	// 11	// vender dependent packet processing called (after IPP processing finished)
	// IPP_OPERATOR_HDR,		//consider later...
};

// IPP operands type
enum {
	// all operands are used as int
	IPP_OPERAND_VALUE = 1,	// decimal value	// int
	IPP_OPERAND_STRING,	// string "..."		// num in str[num]
	IPP_OPERAND_VARIABLE,	// pre-defined symbol	// num in var[num]
	IPP_OPERAND_OFFSET,	// jmp offset		// target inst_line
	IPP_OPERAND_REG_A,	// register A		// 0:val, 1:ptr
	IPP_OPERAND_REG_X,	// register X           // 0:val, 1:ptr
	IPP_OPERAND_EXT,	// extension		// IPP_EXT_xxx 
	IPP_OPERAND_PROC_ID	// call target		// other processor ID
};

// IPP operands extension
enum {
	IPP_EXT_LEN = 1,	// skb->len
	IPP_EXT_PROTO,		// skb->protocol
	IPP_EXT_TYPE,		// skb->pkt_type
	IPP_EXT_POFF,		// Payload start offset
	IPP_EXT_IFIDX,		// skb->dev->ifindex
	IPP_EXT_NLA,		// Netlink attribute of type X with offset A
	IPP_EXT_NLAN,		// Nested Netlink attribute of type X with offset A
	IPP_EXT_MARK,		// skb->mark
	IPP_EXT_QUEUE,		// skb->queue_mapping
	IPP_EXT_HATYPE,		// skb->dev->type
	IPP_EXT_RXHASH,		// skb->hash
	IPP_EXT_CPU,		// raw_smp_processor_id()
	IPP_EXT_VLAN_TCI, 	// skb_vlan_tag_get(skb)
	IPP_EXT_VLAN_AVAIL, 	// skb_vlan_tag_present(skb)
	IPP_EXT_VLAN_TPID,	// skb->vlan_proto
	IPP_EXT_RAND,		// prandom_u32()
};

struct ipp_instruction {
	char 	*code_line;	// original instruction string
	int	line_len;

	// [label:] [opcode [operands]] [; comment]

	char 	*label;
	// instead of opcode string, we use func pointers to each opcode handling func. 
	int 	(*opcode)(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);

	char 	num_operand;
	char 	operand_type[IPP_MAX_ARG];
	uint64_t operand[IPP_MAX_ARG];	// used as integer or pointer
	int 	addr_mode; 	//addr_mode for operands
};

//flow metadata is a general form of "scratch memory"(M[]) in BPF.
//but not implemented in this version.. 
/*
struct ipp_metadata_list {
	struct ipp_metadata_list *next;

	char 	T;	//metadata identifier in this filter. 0~127
	int 	L;	//length of data.
	char 	*V;	//must be initialized in pre-processing code
};
*/

struct ipp_user_var {
	char *var_name;
	int var;
};

struct ipp_user_str {
        char *str_name;
        char *str;
        int str_len;
};


// ipp engine status
enum {
	IPP_STATUS_OFF = 1,	
	IPP_STATUS_WAITING,	//initialized, but has no working processor yet
	IPP_STATUS_LOCK,	//adding or deleting processor
	IPP_STATUS_ON,
	IPP_STATUS_BUSY, 	//processing other packet (multiple CPU situation)	//it must be remaked later, using RCU
	IPP_STATUS_ERR,
	//add later
};

// ipp engine variables for a datapath
struct ipp_engine {
#ifndef IPP_MODE_SINGLE
	//which datapath this engine belongs to
	struct datapath *dp;
#endif
	//ipp engine status
	char status;
	spinlock_t engine_lock;

	//installed processors
	//logically "vport->attached_processor" is correct, but not in this time..
	int num_instance;
	struct ipp_instance *instance_list;
	
	//active processor list. call these processors in every inbound packets.
	int num_active;
	struct ipp_active_list *active_list;

	//global variables
	int next_temp_id;
};

struct ipp_active_list {
	struct ipp_active_list *next;
	
	struct ipp_instance *instance;
	int id;
};

struct ipp_instance {
	struct ipp_instance *next;
	
	// an ipp instance is identified by its ID and attached vport 
	// ID is a globally unuque integer for this processor
	// if ID is not set by ipp code, the processor never been called by other processors, 
	// and temp id (range <= IPP_ID_RESERVED) is assigned automatically
	int id;
	spinlock_t instance_lock;

	// vport is not used in this version.. 	
	//struct vport *vport;

	//processor attributes
	uint8_t action_priority;
	bool active;			// active: recv every inbound packet, default TRUE
	bool allow_call; 		// allow_call: other processor call this instance by id

#ifdef __IPP_FOR_OVS
	bool key_extract;		// TRUE enables key_extract(ovs header parsing)	
#endif	// __IPP_FOR_OVS

	//stats 
	struct flow_stats stats;

	//processor code
	char *prog;	//MAX_IPP_SIZE
	int prog_size;

	//parsed code
	struct ipp_instruction *inst[IPP_MAX_LINENUM];		
	int inst_num;	// # of instruction lines. MAX_LINE_NUM

	//new skb for packet modification
	struct sk_buff *nskb;

	//non-volatile memory
	struct ipp_user_str str[IPP_MAX_STRING];
	int str_num;

	struct ipp_user_var var[IPP_MAX_VARIABLE];
	int var_num;
	
	//flow metadata 
	//struct ipp_metadata_list *flow_metadata;
	//char metadata_num;	// # of metadata	

	//stack
	
	// original BPF registers (check later)
	int 		PC;	//program counter
	uint32_t 	A;	//32 bit wide accumulator
	uint32_t 	X;	//32 bit wide X register

	// original BPF non-volatile memory
	uint32_t	M[16];	//16 x 32 bit wide misc registers aka "scratch memory store"
};



// data structures used for actions 

struct ipp_action_list {
	struct sk_buff *out_skb[IPP_MAX_PKTOUT];
	int out_port[IPP_MAX_PKTOUT];
	uint8_t out_num;
	
	bool ignore;	// ignore lower priority level action
	bool normal;	// vender dependent processing required
};

struct ipp_packet_metadata {
	struct datapath *dp;		// datapath
	struct sk_buff *skb;		// original pkt
	
#ifdef __IPP_FOR_OVS
	struct sw_flow_key *key;	// parsed hdr by ovs
#endif //__IPP_FOR_OVS
	
	//action codes for this packet
	struct ipp_action_list action_list[IPP_MAX_PRIORITY+1];
};


// install/uninstall a processor code. ret 0 means success.
int ipp_install_processor (struct ipp_engine *ipp, char *prog, int prog_size, const struct vport *vport); // vport is not used in this version.. 
int ipp_uninstall_processor (struct ipp_engine *ipp, int id);
// int init_processor (int id);		//reset processor to initial status




// ipp code line classifier
enum {
	IPP_LINE_TRIMED = 1,	//empty line or comment line
	IPP_LINE_DIRECTIVE,	//preprocessor directive line
	IPP_LINE_INSTRUCTION,	//instruction line
	IPP_LINE_EOF,		//eof
};

//read a line from ipp code. returns one of ipp code line classifiers.
int ipp_readline (char **p_remain_str, char *line_str, int *line_len);



// ipp code token classifier
enum {
	IPP_TOKEN_STRING = 1,	// "blah blah"
	IPP_TOKEN_BRACKET,	// [blah blah]
	IPP_TOKEN_INTEGER,	// 123
	IPP_TOKEN_OPERATOR, 	// + - * / ...
	IPP_TOKEN_LABEL,	// abc:
	IPP_TOKEN_EOF,		// eof
	IPP_TOKEN_ELSE,		// operator, operands, variable, ...
};

//read a token from the line. returns one of ipp code token classifiers.
int ipp_readtoken (char **p_line_str, char *token_str, int *token_len, int *token_val);



// ipp operand addressing mode classifier
enum {
	IPP_ADDR_MODE_0 = (1 << 0),   // 1	// x/%x		// Register X
	IPP_ADDR_MODE_1 = (1 << 1),   // 2	// [k]		// BHW at byte offset k in the packet
	IPP_ADDR_MODE_2 = (1 << 2),   // 4	// [x + k]	// BHW at the offset X + k in the packet
	IPP_ADDR_MODE_3 = (1 << 3),   // 8	// M[k]		// Word at offset k in M[]
	IPP_ADDR_MODE_4 = (1 << 4),   // 16	// #k		// Literal value stored in k
	IPP_ADDR_MODE_5 = (1 << 5),   // 32	// 4*([k]&0xf)	// Lower nibble * 4 at byte offset k in the packet
	IPP_ADDR_MODE_6 = (1 << 6),   // 64	// L		// Jump label L
	IPP_ADDR_MODE_7 = (1 << 7),   // 128	// #k,Lt,Lf	// Jump to Lt if true, otherwise jump to Lf
	IPP_ADDR_MODE_8 = (1 << 8),   // 256	// #k,Lt	// Jump to Lt if predicate is true
	IPP_ADDR_MODE_9 = (1 << 9),   // 512	// a/%a		// Accumulator A
	IPP_ADDR_MODE_10 = (1 << 10), // 1024	// extension	// BPF extension
	IPP_ADDR_MODE_NULL = (1 << 11),	// 2048	// (null)	// No operand
};

// special readtoken that can validate operand by its addressing modes
// if addr_mode is not NULL, validate the operand by the given addr_mode
// if addr_mode is NULL, classify addr_mode automatically
// returns result addr_mode if validation successed, and NULL if validation falied.
int ipp_readoperand (struct ipp_instance *proc, struct ipp_instruction *inst, char *operand_str, int len, int addr_mode);


// process a packet with a given ipp engine
#ifdef __IPP_FOR_OVS
int ipp_engine_run (struct datapath *dp, struct ipp_engine *ipp, struct sk_buff *skb, struct sw_flow_key *key);
#else //__IPP_FOR_OVS
int ipp_engine_run (struct ipp_engine *ipp, struct sk_buff *skb);
#endif //__IPP_FOR_OVS

// apply action list
#ifdef IPP_MODE_SINGLE
int ipp_run_action(struct datapath *dp, struct ipp_engine *ipp, struct ipp_packet_metadata *pkt);
#else
int ipp_run_action(struct ipp_engine *ipp, struct ipp_packet_metadata *pkt);
#endif
void ipp_pkt_output(struct datapath *dp, struct sk_buff *skb, int out_port);

//etc utils
#ifdef IPP_MODE_SINGLE
struct ipp_engine *ipp_engine_init (void);
#else //IPP_MODE_SINGLE
struct ipp_engine *ipp_engine_init (struct datapath *dp);
#endif //IPP_MODE_SINGLE
int ipp_engine_free (struct ipp_engine *ipp);

struct ipp_instance *ipp_instance_init (void);
int ipp_instance_free(struct ipp_instance *instance);

struct ipp_active_list *ipp_active_init (void);
int ipp_active_free(struct ipp_active_list *active);

//IPP loader device functions (in loader.c)
int ipploader_init(void);
void ipploader_exit(void);

//instance list functions
struct ipp_instance* ipp_find_processor_by_id (struct ipp_engine *ipp, int id);
struct ipp_instance* ipp_find_prev_processor_by_id (struct ipp_engine *ipp, int id);
struct ipp_instance* ipp_find_last_processor (struct ipp_engine *ipp);

//active list functions
struct ipp_active_list* ipp_find_active_by_id (struct ipp_engine *ipp, int id);
struct ipp_active_list* ipp_find_prev_active_by_id (struct ipp_engine *ipp, int id);
struct ipp_active_list* ipp_find_last_active (struct ipp_engine *ipp);

//string matching functions (return -1 if no matched name found)
int ipp_find_ext_by_name(char *token, int len);
int ipp_find_var_by_name(struct ipp_instance *proc, char *token, int len);
int ipp_find_str_by_name(struct ipp_instance *proc, char *token, int len);
int ipp_find_label_by_name(struct ipp_instance *proc, char *token, int len);
//int ipp_find_operator_by_name(char *token, int len, int *addr_mode);	//return operator_id and addr_mode
int (*ipp_find_operator_by_name(char *token, int len, int *addr_mode))(struct ipp_instance *, struct ipp_packet_metadata *, struct ipp_instruction *);	// return operator func*


// operators (called as func pointer)
int ipp_operator_ld(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_ldh(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_ldb(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_st(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_jeq(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_jmp(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_jne(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_add(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_mod(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_ret(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);

// ipp-extended operators
int ipp_operator_out(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_ign(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);
int ipp_operator_norm(struct ipp_instance *processor, struct ipp_packet_metadata *pkt, struct ipp_instruction *inst);

#endif /* ipp.h */

