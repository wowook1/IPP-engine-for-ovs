#!/bin/sh

clear

make clean

make

cp ./linux/openvswitch.ko /lib/modules/3.13.0-32-generic/kernel/net/openvswitch/openvswitch.ko

