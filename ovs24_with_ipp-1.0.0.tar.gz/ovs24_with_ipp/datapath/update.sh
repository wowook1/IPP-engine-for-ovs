#!/bin/sh

clear

make clean

make

killall ovs-vswitchd

rmmod openvswitch

cp ./linux/openvswitch.ko /lib/modules/3.13.0-32-generic/kernel/net/openvswitch/openvswitch.ko

modprobe openvswitch

ovs-vswitchd --log-file --pidfile --detach
