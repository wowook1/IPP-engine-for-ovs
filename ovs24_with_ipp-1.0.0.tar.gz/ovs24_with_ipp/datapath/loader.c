#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/unistd.h>
#include <linux/init.h>
#include <linux/errno.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <asm/io.h>

#include "datapath.h"
#include "ipp.h"

#define _TRUE_          0
#define _FALSE_        -1

// a device file "/dev/ipploader" will be created automatically in this code
#define IPP_DEVICE_NAME "ipploader"

// variables for loader device
static dev_t stDev;
static struct cdev stCDev;
struct class *stClass;

int ipploader_open (struct inode *inode, struct file *filp)
{
	printk(KERN_INFO "IPPLOADER: ipploader_open() is called.. \n");

	// MOD_INC_USE_COUNT;  ---> for Linux Kernel 2.4.x 

	printk(KERN_INFO "IPPLOADER: \t Major number = %d \n", MAJOR(inode->i_rdev));
	printk(KERN_INFO "IPPLOADER: \t Minor number = %d \n", MINOR(inode->i_rdev));
	
	return 0; 
}

int ipploader_release (struct inode *inode, struct file *filp)
{
	printk("IPPLOADER: ipploader_release() is called.. \n");

	// MOD_DEC_USE_COUNT;  ---> for Linux Kernel 2.4.x
	
	return 0;
}

ssize_t ipploader_read (struct file *filp, char *buf, size_t count, loff_t *f_pos)
/* read : data from Device to User Application */
{
	char *dev_data = "ABCD";
	int err;

	// dev_data = kmalloc(count, GFP_KERNEL);
	// because 'dev_data' has initial data("ABCD"), we don't have to kmalloc

	if( (err = copy_to_user(buf, dev_data, count)) < 0 )
		return err;
	/**
	 **	copy_to_user(to, from, n)
	 **/
	
	printk(KERN_INFO "IPPLOADER: ipploader_read() is called.. \n");

	// kfree(dev_data);

	return count;
}

ssize_t ipploader_write (struct file *filp, const char *buf, size_t count, loff_t *f_pos)
/* write : data from User Application to Device */
{
	char *ipp_code;
	int err;

	ipp_code = kmalloc(count, GFP_KERNEL);

	if( (err = strncpy_from_user(ipp_code, buf, count)) < 0 )
		return err;
	
	printk(KERN_INFO "IPPLOADER: ipploader_write() is called.. \n");
	printk(KERN_INFO "IPPLOADER: \t User write data = %s \n", ipp_code);

#ifdef IPP_MODE_SINGLE
	ipp_single->status = IPP_STATUS_LOCK;

	if (ipp_install_processor(ipp_single, ipp_code, count, NULL))
	{
		printk(KERN_ERR "[IPP] ipploader_write error (cannot install IPP code)\n");
		//dp->ipp->status = IPP_STATUS_WAITING;
		//ipp_single->status = IPP_STATUS_OFF;	//only for __IPP_DEBUG
	}
	else ipp_single->status = IPP_STATUS_ON; 
#else // IPP_MODE_SINGLE
	// Fill some code to get dp
	// ...

	dp->ipp->status = IPP_STATUS_LOCK;

	if (ipp_install_processor(dp->ipp, ipp_code, count, NULL))
	{
		printk(KERN_ERR "[IPP] ipploader_write error (cannot install IPP code)\n");
		//dp->ipp->status = IPP_STATUS_WAITING;
		//dp->ipp->status = IPP_STATUS_OFF;	//only for __IPP_DEBUG
	}
	else dp->ipp->status = IPP_STATUS_ON; 
#endif // IPP_MODE_SINGLE
	kfree(ipp_code);

	return count;
}

/*
int ipploader_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg)
{
	printk(KERN_INFO "IPPLOADER: ipploader_ioctl() is called.. \n");

        switch(cmd)
        {
 		case 1:  
                {
			printk("\n");
			printk("IPPLOADER: Keyboard = [1] \n");
                      break;
                }
                case 2:
                {
			printk("\n");
			printk("IPPLOADER: Keyboard = [2] \n");
                       break;
                }
                case 3:
                {
			printk("\n");
			printk("IPPLOADER: Keyboard = [3] \n");
                       break;
                }
                case 4:
                {
			printk("\n");
			printk("IPPLOADER: Keyboard = [4] \n");
 		       break;
                }
                                          
                default:
                        return 0;
        }
        return 0;
}
*/
		
static const struct file_operations ipploader_fops = {
	/**
	 **	for Linux Kernel 2.4.x
	 -----------------------------
	open	: ipploader_open,
	release	: ipploader_release,
	read	: ipploader_read,
	write	: ipploader_write,
	ioctl	: ipploader_ioctl,
	 -----------------------------
	 **/

	.open		= ipploader_open,
	.release	= ipploader_release,
	.read		= ipploader_read,
	.write		= ipploader_write,
//	.ioctl		= ipploader_ioctl,
};


int ipploader_init(void) 
{
	int result;

	printk(KERN_INFO "IPPLOADER: ipploader_init() is called.. \n");

	result = alloc_chrdev_region(&stDev, 0, 1, IPP_DEVICE_NAME);
	if (result < 0) {
		printk(KERN_WARNING "IPPLOADER: \t alloc_chrdev_region failed! \n");
		return result;
	}

	stClass = class_create(THIS_MODULE, IPP_DEVICE_NAME);
	cdev_init(&stCDev, &ipploader_fops);
	result = cdev_add(&stCDev, stDev, 1);
	if (result < 0) {
		printk(KERN_WARNING "IPPLOADER: \t cdev_add failed! \n");
		return result;
	}
	
	device_create(stClass, NULL, stDev, NULL, IPP_DEVICE_NAME);

	printk("IPPLOADER: device %s created\n", IPP_DEVICE_NAME);

	return _TRUE_;
}

void ipploader_exit(void)
/* 해제 함수 : Device Driver를 리눅스 커널에서 삭제하기 위해 필요한 함수와 함수 매크로 */
{
	unregister_chrdev_region(stDev, 1);

	cdev_del(&stCDev);
	device_destroy(stClass, stCDev.dev);
	class_destroy(stClass);

	//return _TRUE_;
}


#ifdef __IPP_FILELOAD
#include <linux/syscalls.h>
#include <linux/fcntl.h>
#include <asm/uaccess.h>
#include <linux/fs.h>

//read file and returns size
int read_file (char *filename, char *buf)
{
    struct file *filp;
    char temp;
    int ret;
    int size;
 
    /* kernel memory access setting */
    mm_segment_t old_fs = get_fs();
    set_fs(KERNEL_DS);
 
    /* open a file */
    filp = filp_open(filename, O_RDONLY, S_IRUSR|S_IWUSR);
    if (IS_ERR(filp)) {
        printk(KERN_DEBUG "[IPP] read_file open error\n");
        return 0;
    }
 
    /* write example */
    //printk("filp->f_pos = %d\n", (int)filp->f_pos);
    //vfs_write(filp, bufs, strlen(bufs), &filp->f_pos);
    //printk("filp->f_pos = %d\n", (int)filp->f_pos);
 
    /* read */
    filp->f_pos = 0;
    size = 0;
    do {
	/*
        ret = vfs_read(filp, bufs, sizeof(bufs)-1, &filp->f_pos);
	bufs[sizeof(bufs)] = 0;
        if (ret != 0) {
            printk(KERN_DEBUG "%s\n", bufs);
        }
	*/
	ret = vfs_read(filp, &temp, 1, &filp->f_pos);
	if (temp != 0) size++;
	    //printk(KERN_DEBUG "%c", buf); 
	    
    } while(ret != 0);

    //buf = kmalloc(size+1, GFP_KERNEL);
    filp->f_pos = 0;
    ret = vfs_read(filp, buf, size, &filp->f_pos);
    *(buf+size) = 0; 

    filp_close(filp, NULL);  /* filp_close(filp, current->files) ?  */
    /* restore kernel memory setting */
    set_fs (old_fs);

    return size+1;
}

#define __IPP_PROG_LOCATION "/home/wowook/ipp_prog_sample"

if (dp->ipp->status == IPP_STATUS_WAITING)
{
	char *buf;
	int ret_temp;
	const struct vport *p = OVS_CB(skb)->input_vport;

	printk(KERN_DEBUG "[IPP] __IPP_FILELOAD\n");
	//buf = 0;
	//buf = kmalloc(IPP_MAX_CODESIZE, GFP_KERNEL);
	buf = kcalloc(sizeof(char), IPP_MAX_CODESIZE, GFP_KERNEL);

	ret_temp = read_file(__IPP_PROG_LOCATION, buf);
	printk (KERN_DEBUG "[IPP] read \"%.10s ...\" size: %d\n", buf, ret_temp); 	
}
#endif //__IPP_FILELOAD
