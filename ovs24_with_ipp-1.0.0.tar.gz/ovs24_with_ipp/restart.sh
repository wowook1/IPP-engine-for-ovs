#!/bin/sh

clear

killall ovs-vswitchd

rmmod openvswitch

modprobe openvswitch

ovs-vswitchd --log-file --pidfile --detach
